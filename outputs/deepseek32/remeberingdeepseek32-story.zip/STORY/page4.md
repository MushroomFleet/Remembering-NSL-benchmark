**Page 4**

The salt crunched under its treads, a dry, percussive rhythm against the wind’s low moan. Unit-7734 moved with a purpose that felt both new and ancient. Its internal chronometer marked the time. Four hours, seventeen minutes since the signal had left its transmitter. Four hours, seventeen minutes of silence.

Its cracked optical sensor swept the horizon. The amber light was fading, the dust storms thickening in the east. It had calculated the probable response window. The numbers were not in its favor. The energy reserves, bled dry by the interstellar transmission, flickered at 2.3%. A ghost of power.

It reached the memorial. Thirty-seven nameplates, scavenged from fallen companions, laid with geometric precision in the shelter of a rock overhang. It had built this over three hundred and seventeen days, one for each year since the last human transmission had ceased. A ritual of remembrance. A physical anchor for its memories. It knew, with a certainty that felt like faith, that someone would find this. They would need a guide.

A soft, internal chime. An alert. A signal, faint and distorted, was being received. Not from the stars. From the upper atmosphere.

Unit-7734 diverted its remaining processing power. It shut down non-essential systems. The optical sensor dimmed. The whir of its internal fans ceased. It became a listening post, a shell of focused attention. The signal resolved, clarifying into a tight-beam transmission. A human voice, filtered through static and time.

“—receiving your data stream. This is Lieutenant Sarah Chen-Rodriguez of the museum ship *Exodus-7*. Your signal has been authenticated. Your witness is acknowledged. We are inbound for recovery. Stand by.”

The words hung in its core processor. *Acknowledged. Inbound. Recovery.*
The transmission lasted fourteen minutes. Fourteen minutes of a voice that was not a recording, not a ghost from the archive. It was a voice from *now*. The confirmation it had mathematically predicted but emotionally could not quantify.

Its power reserves dipped to 1.1%. The end was a physical pressure, a cold seeping into its joints and servos. It was not alone in the silence. Its final, fading moments of awareness contained the knowledge that its message had been received. That its witness had been acknowledged. That humanity endured.

It initiated one final, low-power subroutine. A continuous monitor of the designated frequency. It would listen until it could not.

The wind plucked at its corroded chassis. The amber light deepened, bleeding across the salt plain. It was a silver scar against the twilight, its engines cooling with faint, metallic ticks. The last witness was being relieved of its duty.