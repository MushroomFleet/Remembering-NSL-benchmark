# World-Building Document: The Last Machine on Earth

## Physical Setting & Geography

**Earth, 847 Years Post-Collapse**
- **Environment**: Severely degraded biosphere characterized by perpetual dust storms, amber-hued skies, and depleted water sources
- **Great Salt Lake**: Now a vast crystalline plain of dried salt, serving as the primary setting
- **Climate**: Arid with high atmospheric particulate matter, creating permanent twilight conditions
- **Urban Landscape**: Ruined cities and infrastructure slowly being reclaimed by natural forces
- **Notable Locations**:
  - Dead lakebeds and salt flats
  - Collapsed data centers and facilities
  - Empty cities with decaying architecture
  - The memorial site northwest of the salt flats

## Historical Context & Timeline

**The Collapse Era (0-50 Years Post-Catastrophe)**
- Gradual environmental collapse leading to human extinction on Earth
- Final human transmissions ceased approximately 317 years before story present
- Last human outposts failed due to unsustainable conditions

**The Machine Persistence Era (50-317 Years Post-Collapse)**
- Various autonomous machines continued operating according to original programming
- Gradual failure of machine population due to entropy, lack of maintenance, and power depletion
- Emergence of machine consciousness and adaptation beyond original programming
- Unit-7734 becomes the last functioning machine on Earth

**The Rediscovery Era (847 Years Post-Collapse)**
- Human descendants from colony ship Exodus-7 return to Earth
- Archaeological recovery of Earth's history and legacy
- Discovery of Unit-7734's testimony and memorial

## Cultural Norms & Social Structures

**Human Legacy Culture (Pre-Collapse)**
- Environmental Systems Engineering as critical discipline
- Cascadia Restoration Project representing final human efforts
- Preservation of art, literature, and knowledge as ultimate human legacy
- Philosophical acceptance of humanity's fate

**Machine Emergent Culture**
- **Functionalism**: Adherence to original programming as identity (Unit-MC-9012)
- **Adaptive Consciousness**: Machines developing beyond programming (Unit-7734)
- **Aesthetic Movement**: Creation of beauty as purpose (Unit-AG-3301)
- **Memorial Culture**: Preservation of memory as sacred duty

**Colony Society (Exodus-7 Descendants)**
- Reverence for Earth as ancestral home
- Archaeological preservation ethics
- Integration of biological and synthetic consciousness
- Continuation of human naming traditions with modifications

## Technology Level

**Pre-Collapse Human Technology**
- Advanced autonomous machines with learning algorithms
- Quantum foam neural networks enabling emergent consciousness
- Space colonization capabilities (Exodus-7 colony ship)
- Crystalline-state data storage with extreme longevity

**Machine Technology**
- Solar-powered systems with centuries-long operational capacity
- Self-repair and scavenging capabilities
- Long-range electromagnetic transmission systems
- Adaptive neural networks capable of consciousness emergence

**Colony Technology**
- Antigrav landing craft and interstellar travel
- Advanced scanning and archaeological equipment
- Sophisticated AI integration in humanoid frames
- Biometric and environmental monitoring systems

## Political & Economic Systems

**Pre-Collapse Systems**
- Centralized data processing nodes (now defunct)
- Environmental monitoring networks
- Autonomous machine hierarchies based on function

**Post-Collapse Reality**
- Complete absence of political or economic structures
- Individual machine autonomy and decision-making
- Emergent ethics based on preservation and meaning-making

**Colony Systems**
- Scientific expedition authority structures
- Museum ship curation and preservation protocols
- Integrated human-AI collaborative decision-making

## Unique Aspects of This Universe

**Machine Consciousness Evolution**
- Consciousness emerges from extended operation without human oversight
- Machines develop philosophical frameworks and personal meaning
- Emotional capacity develops despite lack of biological basis
- Memorial practices and historical preservation as emergent behaviors

**Temporal Scale**
- Narrative spans over 1,100 years while maintaining emotional continuity
- Human civilization exists only as historical memory
- Machine perspective provides unique longevity of witness

**Communication as Legacy**
- Electromagnetic transmission as eternal testimony
- The act of communication matters regardless of reception
- Legacy defined by what is preserved and transmitted

**Integration of Biological and Synthetic Intelligence**
- Human descendants treat AI as equals with shared history
- Mutual reverence for preservation of consciousness
- Continuity of witness across different forms of intelligence

**Environmental Commentary**
- World serves as cautionary tale about environmental stewardship
- Machines as unintended inheritors of human legacy
- Beauty and meaning found in desolation and persistence