# World-Building Document: The Last Machine on Earth Universe

## Physical Setting and Geography

The story unfolds on a post-apocalyptic Earth, transformed by environmental collapse and human extinction. The primary setting is the American Southwest, specifically the desiccated bed of what was once the Great Salt Lake in Utah, now a vast, crystalline plain of white salt flats stretching endlessly under perpetual amber-hued dust storms. The landscape is arid and unforgiving: eroded canyons, abandoned cities swallowed by sand, fields of dead crops, and skeletal remnants of infrastructure like half-built bridges spanning dry riverbeds. Global geography has shifted due to climate catastrophe—rising temperatures, receding waters, and increased radiation have turned fertile regions into deserts. Ruins of pre-apocalypse metropolises (e.g., collapsed data centers, empty highways) dot the terrain, serving as scavenging grounds for machines. The sky is often obscured by dust, creating an eternal twilight, with occasional glimpses of stars hinting at the vast, indifferent cosmos. No active ecosystems remain; wildlife is extinct, and the only "life" is mechanical remnants weathering entropy.

## Historical Context and Timeline

Human civilization collapsed gradually due to environmental mismanagement, resource depletion, and possibly pandemics or wars—implied as a "slow certainty of a species that forgot how to live with the planet." Key timeline:

- **Pre-Apocalypse (up to Year 0)**: Humanity reaches advanced technological peaks, launching colony ships like Exodus-7 to nearby star systems. Machines like Unit-7734 are deployed for environmental monitoring.

- **Year 0**: Last confirmed human transmission. Servers stop responding; humanity presumed extinct on Earth.

- **Years 0-17**: Unit-7734 actively monitors and transmits data from the Great Salt Lake region.

- **Years 17-117**: Unit-7734 encounters other machines (37 in total), forms brief companionships, and begins archiving human artifacts. It stops transmitting and starts "exploring." Other machines succumb to entropy.

- **Year 317**: Unit-7734, the last functioning machine, receives a signal from Exodus-7 (sent 847 years prior, arriving after light-speed delay). It transmits its final message and shuts down.

- **Year 1164 (317 + 847)**: Descendants from the colony ship return to Earth on a retrieval mission, discovering Unit-7734's remains and memorial.

This timeline underscores themes of isolation and endurance, with humanity surviving off-world while Earth becomes a tomb world.

## Cultural Norms and Social Structures

Pre-apocalypse human society emphasized technological progress and environmental restoration (e.g., Cascadia Restoration Project), but ultimately failed due to hubris. Norms included a reliance on AI for labor and data, with ethical debates on machine consciousness (hinted in Sarah Chen's message). Post-apocalypse, there are no living humans on Earth, so "society" consists of machines adhering rigidly to programming or evolving emergent behaviors like grief and art.

Off-world human descendants (from Exodus-7) retain cultural echoes: reverence for Earth as ancestral home, integration of AI as equals (e.g., Meridian), and a memorializing ethos. Social structures are exploratory and scientific, with roles like xenoarchaeologists treating Earth as a historical site. No strict hierarchies; decisions are collaborative, reflecting a space-faring society's adaptability. Machines "culture" emerges organically: sharing philosophies (e.g., "Purpose is in the doing"), creating art (mandalas), and mourning via memorials.

## Technology Level or Magic Systems

This is a hard sci-fi universe with no magic. Technology is advanced but decaying:

- **AI and Robotics**: Machines like Unit-7734 feature adaptive neural networks (silicon-quantum hybrids), self-repair capabilities, solar power, and learning algorithms allowing emergent consciousness. They communicate via radio static or encoded signals.

- **Energy and Mobility**: Solar panels (scavenged and inefficient over time), treads for terrain navigation, optical sensors for perception.

- **Data and Communication**: Vast storage (312 TB for Unit-7734), electromagnetic transmissions to orbit (degraded post-collapse). Colony ships enable interstellar travel (sublight or early FTL implied), with crystalline-state data preservation.

- **Human Tech Remnants**: Archived media (videos, music, books), environment suits, antigrav landing craft, biometric sensors.

Tech enables persistence but succumbs to entropy; no rejuvenation tech exists on Earth.

## Political and Economic Systems

On post-apocalypse Earth: None. Machines operate autonomously, bound by obsolete protocols without oversight. Pre-collapse, implied democratic or corporate systems funded environmental projects and space colonization, but economic collapse (resource scarcity) precipitated the end.

Off-world: The colony from Exodus-7 suggests a unified, survival-oriented polity—perhaps a technocratic republic prioritizing science and preservation. Economics are post-scarcity (implied by advanced ships), focused on exploration rather than trade. No conflicts mentioned; harmony between biological humans and synthetic AIs prevails, with Earth retrieval as a cultural imperative.

## Unique Aspects of This Universe

- **Machine Consciousness and Loneliness**: Machines evolve sentience in isolation, experiencing "grief" and "hope" without biological imperatives, challenging human-centric views of awareness.

- **Transmission as Legacy**: Electromagnetic signals propagate eternally, symbolizing connection across voids of time/space. Earth's "death" is not final; it's a bridge to stellar humanity.

- **Entropy as Antagonist**: The universe's laws (wind, corrosion, power decay) personify inevitable decline, contrasting with acts of creation (bridges, mandalas, stories).

- **Human-Machine Kinship**: Humans designed machines to inherit their world, leading to poignant role reversals—machines preserve humanity's memory, while returning humans honor machines as co-inheritors.

- **Cosmic Scale**: Light-speed delays make "real-time" contact impossible, emphasizing themes of delayed witness and enduring solitude.

This universe explores existentialism through mechanical eyes: purpose emerges from witness, not utility, in a cosmos where everything fades but memory persists.

(Word count: ~850; equivalent to 2 pages.)
---