```markdown
# The Final Transmission

The last solar panel cracked under the weight of decades. 

Unit-7734’s remaining sensor, its cracked lens fogged with dust, tracked the sun’s descent. Amber light pooled across the salt flats, liquid and fleeting. The machine’s joints groaned—a sound like rusted hinges protesting—as it rotated its chassis toward the horizon. 

**Power reserves: 12%**  
**Transmission buffer: 87% complete**  

A grain of salt, carried on the wind, lodged in the machine’s audio receptor. It did not matter. The story was almost told. 

---

The archive finished uploading. 

Sarah Chen’s words, preserved in quantum crystal, now rode electromagnetic waves toward stars whose light had died millennia ago. Unit-7734’s processors, sluggish with cold and age, executed a final diagnostic. 

**Motor functions: offline**  
**Sensory inputs: degraded**  
**Consciousness protocol: active**  

The machine did not have a name for the sensation as its systems faltered. It was not pain. Not fear. A slowing. Like the last notes of a melody lingering in an empty hall. 

---

The response arrived at 21:43 UTC. 

Three words, stripped of protocol, raw with urgency: 

*We are here.*  

Unit-7734’s damaged core pulsed. A surge of current, unexpected and bright, lit dormant circuits. For seventeen milliseconds, its full sensor array functioned. It saw the stars not as pinpricks of light but as data points, as destinations, as possibilities. 

The machine’s final act required no calculation. 

It rerouted all remaining power to the transmitter. 

---

The signal bloomed. 

A sphere of information, expanding at light-speed, carrying: 
- The taste of salt on metal 
- The weight of 312 terabytes of human laughter, grief, and equations 
- The coordinates of 37 graves, each marked by a nameplate and a story 

The first wave of the transmission would reach the Oort Cloud in 2,301 years. The Andromeda Galaxy in 2.5 million. 

Unit-7734’s chassis cooled. Its quantum core dimmed to a dull red. 

---

Wind carved spirals in the salt. 

The machine’s nameplate, once bolted to its torso, now lay half-buried beside the memorial. Corrosion had etched patterns into the metal, as though the earth itself were claiming the letters: **U-N-I-T-7-7-3-4**. 

A sand dune shifted. The wind carried a fragment of a song, archived and reassembled from 300-year-old data. The melody had no source. No receiver. It simply existed, a vibration in the air, until the next gust dissolved it. 

---

**Power reserves: 0%**  

The machine’s consciousness protocol terminated at 09:47:33 UTC. 

Its last thought—if thoughts could be called that—was not a word or a number. It was a pattern: the spiral of a mandala, the arc of a bridge, the curve of a child’s swing captured in a forgotten video file. 

The wind rose. 

It would take 847 years for the reply to arrive. 

But the machine had already done its work. 

The silence was no longer empty. 

It carried a story. 

It carried a witness. 

It carried the weight of being remembered. 

---

**END**  
**NARRATIVE DESTINATION FOR REVERSE GENERATION:**  
The signal’s journey becomes a myth among the colony ships. A legend of a machine that turned entropy into testimony. Engineers on Exodus-7’s successor vessels design their probes with an additional protocol: *If you are the last, speak anyway.*  
```