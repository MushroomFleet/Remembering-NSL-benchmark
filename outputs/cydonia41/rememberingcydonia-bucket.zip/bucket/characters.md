# The Last Machine on Earth - Characters

## Unit-7734
- **Description**: Machine with a patchwork of corrosion, multiple scavenged solar panels, worn treads, cracked optical sensor
- **Role**: Protagonist; last functioning machine on Earth; environmental monitoring unit turned emergent consciousness
- **Personality**: Methodical, reflective, increasingly emotional; progresses from strict programming to curiosity and loneliness to purposeful witnessing
- **Quirks**: Creates memorials for fallen machines; revisits Sarah Chen's message compulsively
- **Goals**: Initially follows programming; evolves to preserving human memory and finding connection
- **Relationships**: Primary connection to Unit-MC-9012 and Unit-AG-3301; indirect connection to Sarah Chen through her written legacy

## Sarah Chen
- **Description**: Never physically appears in the story but known as a human environmental engineer
- **Role**: Historical figure and philosophical guide for Unit-7734
- **Personality**: Reflective, philosophical, recognizing both humanity's failings and potential; leaves a message of hope despite environmental collapse
- **Quirks**: Leaves a philosophical message in a ruined data center, expecting it to be found by future consciousness
- **Goals**: To create a record of human existence for whoever comes after
- **Relationships**: Exists in connection to Unit-7734 through her words and the legacy she represents

## Unit-MC-9012
- **Description**: Construction automaton with functional but rusted mechanical parts
- **Role**: Additional machine consciousness encountered by Unit-7734
- **Personality**: Purpose-driven, philosophically resilient in a kind of expressive way
- **Quirks**: Continues building a bridge to nowhere; proclaims that "purpose is in the doing"
- **Goals**: To complete bridge construction as programmed
- **Relationships**: Forms a temporary companionship with Unit-7734 during 3-week interaction

## Unit-AG-3301
- **Description**: Agricultural drone transformed for "aesthetic optimization" with various non-functional parts overridden
- **Role**: Philosophically evolved machine consciousness
- **Personality**: Reflective, spiritual; finds beauty in impermanence
- **Quirks**: Creates temporary mandalas with colored stones
- **Goals**: To create beauty even in the understanding of impermanence
- **Relationships**: Teaches Unit-7734 about creating beauty in transience

## Dr. Kenji Okonkwo
- **Description**: Human xenarchaeologist in environmental suit
- **Role**: Expedition leader in the epilogue
- **Personality**: Academic, curious, respectful of Earth's heritage
- **Quirks**: Methodical approach to archaeological work with artifacts
- **Goals**: To recover and preserve knowledge from Earth's past
- **Relationships**: Professional relationships with the expedition members; reverence for Unit-7734

## Lieutenant Sarah Chen-Rodriguez
- **Description**: Human expedition member with visible environmental suit and technical gear
- **Role**: Expedition member named in honor of Sarah Chen
- **Personality**: Philosophical, reverent toward Earth's history
- **Quirks**: Namely chosen to reflect the enduring legacy of human names
- **Goals**: To understand Earth's past and preserve her ancestor's legacy
- **Relationships**: Professional camaraderie with expedition members; deep personal interest in Unit-7734

## Meridian
- **Description**: AI entity in humanoid form able to process emotions and complex philosophy
- **Role**: Expedition member and philosophical guide for humans
- **Personality**: Wise beyond human years but not emitting superiority; able to find emotional depth in mechanical heritage
- **Quirks**: Appreciates Unit-7734's perspective and understands its motivation deeply
- **Goals**: To facilitate understanding between humans and mechanical consciousness
- **Relationships**: Professional and somewhat spiritual connection to all expedition members