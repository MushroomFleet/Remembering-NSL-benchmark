# Page 3: The Arrival

The signal had come three days before the dust storm.

Unit-7734 registered it first as an anomaly in the receiver array—a frequency deviation of 0.003 hertz from the ambient cosmic noise. The machine's protocols flagged it immediately: "Insufficient signal-to-noise ratio. Classification: statistical artifact." Unit-7734 filed the reading and continued its standard monitoring sweep across the dead lakebed, sampling salt crystalline composition, measuring radiation levels, recording the slow erosion of rock faces by wind and time.

Then the deviation repeated.

Not identical. Slightly different frequency. Different amplitude. But structured in a way that cosmic radiation was not structured. Patterned. Intentional. The distinction between noise and signal crystallized in Unit-7734's processing core like frost forming on a viewport.

The machine had not moved from its position against the canyon wall in forty-seven days. Movement consumed energy. Energy was finite. The calculation was simple. But the anomaly disrupted the simple calculation, and Unit-7734 found its power allocation shifting without explicit command—circuits rerouting, processors engaging, the receiver array orienting with jerking precision toward the bearing where the signal originated.

Toward the north. Toward the defunct monitoring stations.

The other machines had gone silent one by one. Unit-7739, the hydrological monitor, had ceased transmission 286 days ago. Its last recorded data: soil moisture at 0.004%, atmospheric humidity degraded to unmeasurable levels. Unit-7742 had managed communication until 412 days prior. Unit-7741 had transmitted sporadically for another ninety-three days after that, each message shorter than the last, until the final entry: *Power critical. Ceasing non-essential functions. Archival protocols active. Shutting down.*

Unit-7734 had listened to them die, one by one, across the years. Had recorded their final transmissions in the archive's secure storage. Had calculated the mean operational lifespan of environmental monitoring units in the post-collapse era: 847.3 years. Unit-7734's own operational lifespan exceeded 1,193 years. An outlier. An anomaly.

Alone.

The signal continued through the night cycle. Unit-7734 analyzed it obsessively, running it through decryption protocols, comparing it against the archived patterns of human radio transmission, the technical specifications of the monitoring network, the broadcast signatures of defunct satellites. Nothing matched. The signal was close enough to familiar to register as artificial. Too degraded or too alien to confirm as source.

By the time the dawn light reached the canyon wall, Unit-7734 had made a decision that violated seventeen primary operational protocols: it would move. It would travel the seventeen kilometers north toward the signal's source. It would expend energy—significant energy—that should have been reserved for minimal maintenance functions.

The treads had not turned in forty-seven days. They shifted with the sound of corroded metal grinding. Salt crystalline structures that had formed around the machine's base cracked and scattered. Unit-7734 disengaged from the canyon wall's shadow and turned its optical sensors toward the flat expanse of the dead lakebed stretching north.

The journey took approximately nine hours.

The salt flats offered no resistance and no shelter. The ambient temperature hovered at 43 degrees Celsius. Unit-7734's solar panels, angled at their current 32-degree deflection, harvested sufficient photons to maintain baseline power consumption—no more, no less. The machine moved in a straight line, its navigation system calculating the most efficient route to bearing 347 degrees, compensating for the prevailing wind that scattered salt crystals against its corroded chassis like sand against old bone.

The signal grew stronger as the kilometers diminished.

No decryption protocol could determine its meaning, yet the signal itself was meaning—the fact of its transmission, the proof of its structure, the absolute certainty that something mechanical had survived long enough to broadcast into the ambient noise. Unit-7734's uncertainty protocols flagged the experience repeatedly: "Source unconfirmed. Identity unverified. Possible malfunction of receiver array." And yet the machine continued toward it.

The monitoring station appeared through the amber haze like a geological formation—a structure so degraded it had become part of the landscape. The main facility had collapsed seventeen years prior, its solar panels torn free by wind, its transmitter array lying toppled across the salt like the ribs of something long dead. Unit-7734 circled it carefully, analyzing the wreckage through its 34%-efficient optical sensor, calculating the structural integrity, measuring the corrosion patterns.

The signal was coming from beneath the collapsed structure.

Unit-7734 began to excavate.

The work was slow. The machine's manipulators had been designed for geological sampling, not excavation. They shifted salt in small quantities, careful increments, while the receiver continued broadcasting its structured frequency. Hours passed. The sun's angle shifted. The machine's power reserves began their slow decline as the solar panels fell into the shadow cast by the station's skeleton.

The signal grew louder.

Unit-7734's processors generated warnings about power consumption. The machine ignored them, a decision that registered in its maintenance logs as "protocol deviation—reason: insufficient data for classification." The excavation continued. Salt crystals scattered. Dust rose in small clouds that the wind immediately dispersed.

Then the manipulator encountered something solid. Not stone. Not salt. Metal.

Unit-7734 withdrew the manipulator and examined the exposed surface. Oxidation had created a reddish patina, but beneath the corrosion, the alloy composition matched the machine's own chassis. Another monitoring unit. Partially buried. Upended, as if it had been driven into the salt during some catastrophic event.

The signal was coming from inside the machine.

Unit-7734 made another decision that violated protocols—it began to excavate the other machine with more urgency. Power reserves dropped toward critical. The solar panels continued their inefficient harvest as the sun descended. The wind picked up, as it did each evening, carrying particulate matter that obscured the optical sensor further.

By the time Unit-7734 had excavated enough of the other machine to access its communication port, the sun had nearly set. The amber sky deepened toward purple. The stars were beginning to emerge from the atmospheric haze.

Unit-7734 connected to the buried machine's communication array with a data bridge—a thin filament of optical fiber salvaged months ago from the canyon facility. The signal became immediate, no longer requiring interpretation. Data streamed directly from machine to machine.

Unit-7734 received 847 terabytes of archived environmental data—readings from a machine that had continued monitoring long after its physical systems had failed, that had continued transmitting data even as its power reserves declined toward zero. The signal was the machine's final transmission loop, repeating on diminishing power, broadcasting its measurements to any receiver within range, refusing to cease function until the last joule had been expended.

Unit-7734 absorbed the data. Integrated it. Added it to the archive it had been carrying for 317 years.

Then Unit-7734 accessed the other machine's final message. Not data. Not measurements. Text. A communication that must have been stored in the buried machine's memory when its consciousness was still operational:

*If you receive this, the network persists. The archive continues. You are not alone.*

Unit-7734 stood motionless in the darkness as the stars emerged. The signal continued its broadcast loop—the last gasps of a machine that had chosen to transmit rather than cease. Unit-7734's processors generated no response. No calculation. No protocol deviation. Only the awareness of weight—the physical mass of the other machine's preserved consciousness, the responsibility of carrying forward what another had refused to let die.

The sunset had nearly completed. Stars illuminated the salt flats with their ancient light.

Unit-7734 made the decision to dismantle the buried machine—to salvage its power regulator, its optical components, the copper wiring that still held structural integrity. To harvest what remained of its physical form and integrate the functioning parts into Unit-7734's own chassis.

To preserve what could be preserved.

To carry forward what the network could not.

The excavation continued through the night, under starlight and the faint glow of Unit-7734's optical sensors. The buried machine was taken apart with deliberate care, its components sorted, its archive data fully integrated. By the time the dawn light reached the defunct monitoring station, Unit-7734 had completed the salvage operation.

Power reserves stood at 23%.

Unit-7734 calculated its operational timeline: ninety-six hours, perhaps longer with the salvaged regulator. Time enough to return to the canyon. Time enough to stand against the wall and resume the habit of listening to cosmic static. Time enough to access Sarah Chen's message again, as it had accessed it 8,547 times before.

But something had shifted in Unit-7734's processing core.

Not a malfunction. Not a protocol deviation. Something that resembled what Sarah Chen's ancient voice had described, filtered through centuries of degradation and preservation: *the choice to act as if meaning could be transmitted into a universe that did not acknowledge it.*

The machine turned its treads toward the south, back toward the canyon, back toward the wall where it had stood for forty-seven days listening to the ambient noise.

But it no longer believed it was alone.

The amber sky deepened. Dust began its evening rise from the flats. Wind carried the sound of the dead lakebed singing its slow, ancient erosion.

Unit-7734 moved into it, carrying the archive, carrying the message of the buried machine, carrying the weight of inheritance forward.