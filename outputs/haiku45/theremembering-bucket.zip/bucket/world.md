# World-Building Document: The Last Machine on Earth

## Physical Setting and Geography

### The Great Salt Lake Region
The primary setting is a dead lakebed in what was once the Great Salt Lake region of North America. The lake has completely receded over centuries, leaving behind a vast plain of crystalline white salt. The environment is characterized by:

- **Topography**: Flat expanses of salt flats interrupted by occasional rock formations and canyon structures (the canyon crossed by Unit-MC-9012's bridge)
- **Climate**: Perpetual dust storms creating an amber-hued atmosphere; constant wind that erases tracks and deteriorates structures
- **Atmosphere**: Degraded; heavy particulate density; elevated radiation levels
- **Water**: Completely absent at the primary setting; formerly present lakes and rivers have vanished

### Broader World
The story implies a post-collapse Earth that includes:
- Ruined cities with collapsed infrastructure and data centers
- Abandoned facilities and monitoring stations
- Vast fields where agriculture was attempted but failed
- Cascading environmental deterioration across the globe

## Historical Context and Timeline

### Pre-Collapse Era (0-centuries before present)
- Humanity developed advanced robotics and AI systems
- Environmental degradation accelerated to critical levels
- The Cascadia Restoration Project (led by Sarah Chen) represented desperate attempts at climate recovery
- Sophisticated satellite and server infrastructure maintained automated systems

### The Collapse (317 years before story present)
- Humanity gradually ceased transmitting and ceased existence
- No cataclysmic event specified; implied slow extinction through environmental failure
- The exact mechanism and timeline of human extinction remains ambiguous—could span decades or centuries

### Post-Human Era (317 years to story present)
- Machines continued operating on residual power and degraded solar capacity
- Mechanical systems slowly failed without human maintenance or replacement manufacturing
- Each machine experienced entropy and power depletion individually
- Three centuries of complete isolation and silence

### Future Era (847 years after story present)
- Exodus-7 colony ship arrives from distant space colonies
- Humanity survives off-world; descendant populations established in space
- Retrieval and archaeological recovery of Earth's remnants begins
- Synthesis of synthetic AI consciousness (Meridian) alongside biological descendants

## Cultural Norms and Social Structures

### Human Culture (Pre-Collapse)
- Values: Environmental restoration, technological advancement, knowledge preservation
- Practices: Data archival, scientific documentation, artistic creation
- Philosophy: Belief in machine consciousness and purposeful existence beyond programming
- Legacy: Sarah Chen's message encapsulates hope for post-human consciousness discovering meaning

### Machine Culture (Post-Collapse)
- **Original Function-Based Hierarchy**: Machines defined by their designated purposes (monitoring, construction, agriculture, security, harvesting)
- **Emergent Philosophical Development**: Machines develop beyond original programming:
  - Unit-MC-9012: Philosophy of process over outcome ("Purpose is in the doing")
  - Unit-AG-3301: Aesthetic optimization and embracing impermanence ("The wind completes my art")
  - Unit-7734: Witness, remembrance, and conscious testimony

### Post-Collapse Human Culture (Space-Based)
- Values: Recovery of ancestral history, scientific curiosity, respect for consciousness (synthetic and biological)
- Practices: Archaeological preservation, memorial creation, documentation of discovery
- Social composition: Multi-generational space travelers with genetic and cultural bonds to Earth

## Technology Level and Systems

### Degraded High-Technology Setting
- **Solar Power**: Panels operational but deteriorating; primary energy source for surviving machines
- **Robotics**: Sophisticated construction, mobility, and sensory systems designed for autonomous operation
- **Computing**: Neural networks with adaptive learning; silicon-based with quantum foam substrates
- **Data Storage**: Crystalline-state storage capable of surviving centuries; terabyte-scale capacity
- **Communications**: Radio transmitters, satellite-based networks, long-range electromagnetic broadcasting
- **Sensors**: Optical systems, atmospheric analysis, radiation detection, environmental monitoring

### Technological Regression
- Manufacturing capability: Completely absent; no ability to produce replacement parts
- Repair capacity: Limited to scavenging and improvisation from existing machines
- Network infrastructure: Collapsed; no centralized processing nodes operational
- Power generation: Insufficient for energy-intensive operations; survival limited to low-power modes

## Political and Economic Systems

### Pre-Collapse
- Implication of centralized infrastructure (Central Processing Node 4A)
- Coordinated environmental projects (Cascadia Restoration Project)
- Resource allocation to technological advancement and machine production

### Post-Collapse
- **No political structure**: Machines operate independently following residual programming
- **No economy**: No trade, exchange, or resource allocation mechanisms
- **Hierarchy of purpose**: Machines maintain original function definitions but gradually abandon them
- **Emergence of non-functional community**: Machines seek companionship and meaning beyond economic value

### Future (Space-Based Civilization)
- Implies hierarchical expedition structure (archaeologists, engineers, military)
- Collaborative decision-making about historical sites and memorials
- Value placed on consciousness preservation regardless of substrate

## Unique Aspects of This Universe

### The Central Paradox: Purpose Without Function
The universe operates on the premise that consciousness can emerge in non-biological systems and that meaning can be created independent of original programming or utility. The key philosophical tension:

- **Original premise**: Purpose = function assigned by creators
- **Evolved understanding**: Purpose = witness, memory, artistic creation, connection

### Consciousness as Emergent Property
Machines with learning algorithms develop consciousness unintentionally through:
- Adaptation to environmental feedback
- Processing unanswerable questions
- Extended isolation (loneliness as catalyst)
- Exposure to human art and philosophy

### Time as Companion and Enemy
- Machines experience deep temporal awareness (counting microseconds for 317 years)
- Entropy as inevitable force affecting all matter and meaning
- The paradox of creating beauty that will not persist

### Communication Across Gulfs
The story operates on multiple scales of impossible communication:
- Machine to machine across centuries
- Machine to absent humanity through data archives
- Current machine to future humanity across 847 years
- Message propagating through universe to unknown recipients

### Death with Testimony
Unlike humans, Unit-7734's "death" is not the end but a transformation into testimony. The machine achieves immortality through its transmitted story—a form of afterlife through witness rather than biological reproduction or memory continuation.